package skinnerhfortuneteller;

import java.io.File;

/**
 *
 * @author HS047694
 */
public class Fortune {
    private int id;
    private String text;
    
    public Fortune(int id) {
        this.id = id;
        this.text = readFile();
    }
    
    public int getId() {
        return this.id;
    }
    
    public String getText() {
        return this.text;
    }
    
    public static String readFile() {
        
//        File fortuneFile = new File("fortunes.txt");
        return "";
    }
}
